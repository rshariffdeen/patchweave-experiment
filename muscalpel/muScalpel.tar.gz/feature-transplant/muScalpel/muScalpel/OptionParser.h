/* 
 * File:   OptionParser.h
 * Author: alex
 *
 * Created on 15 October 2014, 19:16
 */

#ifndef OPTIONPARSER_H
#define	OPTIONPARSER_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

void parse_args(int argc, char * argv[]);


#endif	/* OPTIONPARSER_H */

