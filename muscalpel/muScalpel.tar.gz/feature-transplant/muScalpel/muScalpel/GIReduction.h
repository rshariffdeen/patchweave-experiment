/* 
 * File:   GIReduction.h
 * Author: alex
 *
 * Created on 14 October 2014, 03:44
 */

#ifndef GIREDUCTION_H
#define	GIREDUCTION_H

#ifdef	__cplusplus
extern "C" {
#endif

	void reduceCandidate(char * candidateFile, char * fileOfReducedIndividua, char * TXLTemporaryFolder);


#ifdef	__cplusplus
}
#endif

#endif	/* GIREDUCTION_H */

