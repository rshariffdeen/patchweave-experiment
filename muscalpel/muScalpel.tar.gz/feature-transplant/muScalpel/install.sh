#!/bin/bash

ulimit -s unlimited

#rm -r -f SCALPEL
#mkdir SCALPEL
cd muScalpelTXLSourceCode
make clean
make
cd ..
#mkdir SCALPEL/TXLTools
cp muScalpelTXLSourceCode/*.x muScalpelInstall/
cd muScalpel
make clean
make
cd ..
cp muScalpel/dist/Debug/GNU-Linux-x86/gentrans muScalpelInstall/
