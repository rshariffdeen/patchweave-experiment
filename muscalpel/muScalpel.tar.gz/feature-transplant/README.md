This is the readme file for GenTrans. The tool takes as input a Host program, a Donor program, a marking in the Host for the tranplant place, and the feature required to pe transplanted. It will automatically transplant the required feature from the Donor into the Host.

More informations about running the tool are to be added. The general description of the tool is:

For running this tool, the Donor program must be compiled with different GCC
flags, so a suitable configure or makefile are needed.
The main components are:
• Preparations
For beginning, the user must annotate a place in the Host, for where the
functionality to be inserted. It can be either a place in a function, or a
place outside of a function, in which case, the only variables tried to be
used in the transplanted code (as parameters to the interface), are the
global variables.
1In the Donor, the user may either annotate a place in a function he con-
siders to be the core functionality of the feature, or use two test suits: one
that triggers the functionality to be transplanted, and one that not.
• Interface And Symbol Table
By using TXL, the symbol table will be extracted for the Host. It will
contain all the variable definitions that reach the place annotated as the
transplant location, and all the global variables that are defined in that
context. Also a symbol table for the core function’s parameters is deter-
mined, and the return value’s type of the core function.
According to this, the initial interface is constructed: the parameters are
all the variables in the symbol table of the host, and as a return value is
returned the result of the core feature. So the type of the function would
be according to this. It is also possible for the user to specify a desired
return value, in which case, at the end the tool will try to match variables
of that type, with the returned value (going into struct’s element), or
pointer elements. (This last part is not implemented yet).
• Core Feature Extraction
In the current implementation, GCOV is used for determining the call
graph from the core function on, and the source files of the called functions.
All this functions from the call graph (excepting the places declared as
libraries) are transplanted in a separate file. Also from the graph of include
files, there are transplanted all global declarations that are used in at least
one transplanted function. Conflicting IDs are replaced by appending a
’ ’, how many times it is necessary for obtaining a unique ID.
In the feature implementation (I’m doing like this for the moment, for
allowing GP to run faster, and so to debug easier and faster), it will be
started just with the marked function. GP will search in this call graph,
by extending the search space every time a new unknown function call is
reached. Initially the functions will be empty (just with the abstracted
return value if it is the case), and GP will add LOCs.
At this step there are still some problems related to macro definitions,
and ifdefs that violate the syntactic rules of the grammar. For this I think
about extending the ifdefs according to the makefile commands, and to
user definitions, and then use Coan, for expanding them. For the moment
I’m expanding to the else branch of ifdefs.
• Feature context extractor
Usually the structs used as parameters in the core function, or even simple
types will not be available in the Host’s context, and will not mean the
same thing. For this, the reverse call graph of the function, until the
entry point of the program is constructed. Initially, the identifiers from
every function are abstracted, the return values are identified, saved in a
2repeat, and removed from the function. Also at this point a symbol table
is constructed.
After this, the new abstracted version of the function is parsed. At every
reach of a call to the next function in the call graph, some transformations
are done: the call of the function (if the return value is used) is replaced
with a variable; this variable is instantiated just before the call place, with
the abstract variable from the return instruction of the called function;
before this it is annotated a call to the function; before the call to the
function are defined variable to be used as parameters of the function,
which are instantiated with the values of variables (or statements) from
current function, that are used in the call of the function as parameters.
So, all functions from the reverse call graph will be extended into just one
function, which body will be added in the interface, just above the core
function’s call.
Also, just the statements will receive as annotation a number (starting
from 1), to be used in GP, for line selection. Control statements are not
numbered in general, and will be added once at least a line from there
body is added. If there body is empty, them will be added (I will also try
to add lines without the controls to see if better results may be obtained).
• Skeleton Construction
The skeleton of the feature represents the order in which selected LOCs
by GP are to be inserted into the interface. In C code, it read the list of
transformed functions from the reverse call graph, and then extend all the
annotations for function call with the actual call of the function. Also,
just the lines up to the next function in call graph call are retained, and
the syntactic sugar after it. It is used a fixed point iteration, and the
recursive call stops after not any call function extending is done.
Having the variable mappings from the previous step, before inserting the
body of a function, it is instantiated according to the unique identifiers
for the respective function call (it could be the case that more calls are
done to the next function in the call graph, in the same current function).
The obtained skeleton will represent so a path in the program, from the
entry point up to the call of the core function, where GP will search.
• GP Algorithm
In the GP Algorithm, an individual will be formed by variable mappings
(for the abstracted values to different possible mappings from the con-
structed symbol table of variables from the reverse call graph, and param-
eters to the interface), and by line numbers which represent statements
to be added in the individual. There are two possible different classes of
operations: either above a statement LOC (crossover or mutation, with
delete, add or replace), or above a variable mapping (change to a dif-
ferent if it is possible). The initial population will have one statement
3LOC added, and random mappings for all abstract value where there are
possible mappings.
For instantiation, just the statements contained in the individual are taken
into consideration. Instantiation of the abstract values are done accord-
ing to the mappings in the individual, by using TXL. Also, in the same
TXL program there are identified variable definitions that are used in the
added statements LOCs, and are marked for insertion. The comments
and annotations are removed, and the individual is ready for testing its
fitness.
For fitness, the following things are taken into account: the number of
variables that are still abstract (lower the fitness), whether or not the in-
dividual compiles, the results to test cases. The fittest individuals remain
in the population, and the algorithm stops when the fitness is 100%, or
after a defined threshold value, or when time / number of generations
resources are finished.
• Memory Leaks
Because we stop after the call of the function, usually there will remain
memory leaks. For solving this, the output of Valgrind is interpreted, and
compared to the output of the interface (after the most fitted individuals
are selected). If at the same line is a buffer over flow for example, or if there
are more memory leaks in the interface than in the original program, the
previous GP algorithm is applied, with a changed fitness function. Now,
the fitness takes into account: whether or not the previous test cases
results are kept, and the memory problems removed by a new individual.
This part is not implemented yet.
• Final Reduction
Since is highly probable that some unneeded statements are still kept in
the fittest individuals, finally the previous GP algorithm will be run again.
The fitness show if the previous results to test cases and memory leaks are
still remained after the removal of a LOC. Now, a LOC in an individual
means that that statement to be removed. Also, there will be not any
more mappings in individuals from here. This part is not implemented
yet, but is mostly the same as the GP for feature’s context extraction.
• Integration Test
Finally the integration tests will be run, for showing the impact of the
newly added feature on the old functionalities of the program. Integration
tests may be also run before the memory leaks fixing step.
